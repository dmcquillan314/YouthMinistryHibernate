/*exported broadcast */

var webcenter = webcenter || {},
    broadcast = webcenter.broadcast = webcenter.broadcast || _.extend( {}, Backbone.Events );

$( function() {
    webcenter.appView = new webcenter.AppView();

    // Presentational polyfills.
    Modernizr.load([
        {
            test: Modernizr.csscolumns && Modernizr.csstransforms && Modernizr.csstransforms3d,
            nope: '/static/common/js/plugins.js',
            complete: function() {
                if( ! Modernizr.csscolumns ) {
                    $( '.multicolumn.four-col' ).columnize( {
                        width: 220,
                        columnGap: 20,
                        doneFunc: function() {
                            $( '.multicolumn.eight-col' ).columnize( { width: 460, columnGap: 20 } );
                        }
                    } );
                }
            }
        },
        {
            test: Modernizr.input.placeholder,
            nope: '/static/common/js/polyfills.js',
            complete: function() {}
        }
    ]);

});