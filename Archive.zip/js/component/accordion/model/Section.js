webcenter.Section = Backbone.Model.extend({

	defaults: function() {
		return {
			active: false
		};
	}

});