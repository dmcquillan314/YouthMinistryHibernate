webcenter.AccordionView = Backbone.View.extend({

	el: $( '.accordion' ),

	initialize: function() {
		this.sectionCollection = new webcenter.Sections();

		this.sectionLinks = this.$( '.section-links' );
	},

	render: function() {
		var that = this;

		_.each( this.$el.find( '.section' ), function( section ) {
			new webcenter.SectionView({
				el: section,
				collection: that.sectionCollection,
				sectionLinks: that.sectionLinks
			});
		});

		return this;
	}

});