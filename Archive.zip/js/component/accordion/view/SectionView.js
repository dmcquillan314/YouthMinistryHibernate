webcenter.SectionView = Backbone.View.extend({

	viewIndex: null,

	events: {
		'click a': 'activateSection'
	},

	initialize: function( options ) {
		this.sectionLinks = options.sectionLinks;

		this.listenToOnce( this.collection, 'add', this.addLink );
		this.collection.add({ active: false });

		this.listenTo( this.collection.models[ this.viewIndex ], 'change:active', this.activateSection );
	},

	render: function() { return this; },

	addLink: function( model ) {
		this.viewIndex = this.collection.indexOf(model);
		this.$el.hasClass( 'active' ) && model.set({ active: true }, { silent: true });
	},

	activateSection: function() {
		this.$el.addClass( 'active' ).siblings().removeClass( 'active' );
	}

});