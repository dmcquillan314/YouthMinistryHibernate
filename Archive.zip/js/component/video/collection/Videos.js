webcenter.Videos = Backbone.Collection.extend({

	initialize: function() {}

});