webcenter.Video = Backbone.Model.extend({

	defaults: function() {
		return {
			active: false,
			width: 460,
			isModal: false,
			videoId: '',
			player: null,
			loaded: false
		};
	}

});