/*exported onYouTubeIframeAPIReady */

webcenter.VideoCollectionView = Backbone.View.extend({

	el: $( '.video-container' ),

	broadcast: webcenter.broadcast,

	initialize: function() {
		_.bindAll( this );

		this.videoCollection = new webcenter.Videos();
	},

	render: function() {
		this.loadScript();

		this.broadcast.on( 'video:loadVideos', this.loadContainer, this );

		return this;
	},

	loadScript: function() {
		var tag = document.createElement('script');
		tag.src = "//www.youtube.com/iframe_api";

		var firstScriptTag = document.getElementsByTagName('script')[0];
		firstScriptTag.parentNode.insertBefore(tag, firstScriptTag);
	},

	loadContainer: function() {
		var that = this;

		_.each( that.$el, function( video ) {
			var isModal = $(video).hasClass( 'modal' );
			var view = new webcenter.VideoView({
				el: $(video),
				collection: that.videoCollection,
				isModal: isModal,
				videoId: $(video).data('vidid'),
				player: null,
				autoplay: ($(video).hasClass('autoplay') ? 1 : 0)
			});
			view.render();
		});
	}

});

function onYouTubeIframeAPIReady() {
    webcenter.broadcast.trigger( 'video:loadVideos' );
}