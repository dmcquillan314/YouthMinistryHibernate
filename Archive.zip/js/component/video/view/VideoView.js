webcenter.VideoView = Backbone.View.extend({

	viewIndex: null,
	loaded: false,

	broadcast: webcenter.broadcast,

	initialize: function( options ) {
		_.bindAll( this, 'onPlayerReady', 'onPlayerStateChange', 'stopVideo', 'playVideo', 'autoplayVideo' );

		this.listenToOnce( this.collection, 'add', this.addVideo );
		this.collection.add({
			active: false,
			width: options.width,
			isModal: options.isModal,
			videoId: options.videoId
		});

		// change active listener goes here
		options.isModal && this.broadcast.on( 'video:closeModal', this.stopVideo );
		options.isModal && this.broadcast.on( 'video:openModal', this.autoplayVideo );
	},

	addVideo: function( model ) {
		this.viewIndex = this.collection.indexOf(model);
	},

	render: function() {
		var model = this.collection.models[ this.viewIndex ];

		this.playerId = 'player' + this.viewIndex;

		if(model.attributes.isModal) {
			this.$el.children( '.bottom-content' ).attr('id',this.playerId);
		} else {
			this.$el.attr('id',this.playerId);
		}

		this.player = new YT.Player(this.playerId, {
				height: (this.$el.width() / 4) * 3,
				width: this.$el.width(),
				videoId: this.options.videoId,
				playerVars: {
					'enablejsapi': 1,
					'autoplay': this.options.autoplay,
					'controls': 1,
					'rel': 0,
					'modestbranding': 1,
					'showinfo': 0,
					'color': 'white',
					'wmode': 'opaque'
				},
				events: {
					'onReady': this.onPlayerReady,
					'onStateChange': this.onPlayerStateChange
				}
		});

		this.collection.models[ this.viewIndex ].set( 'player', this.player );

		return this;
	},

	onPlayerReady: function() {
		this.collection.models[this.viewIndex].attributes.loaded = true;
		if(this.options.isModal) {
			this.collection.models[this.viewIndex].attributes.player.stopVideo();
		}
	},

	onPlayerStateChange: function() {},

	playVideo: function() {
		this.collection.models[this.viewIndex].attributes.loaded && this.collection.models[this.viewIndex].attributes.player.playVideo();
	},

	autoplayVideo: function() {
		if(this.options.autoplay && this.$el.hasClass("active") ) {
			this.playVideo();
		}
	},

	stopVideo: function() {
		_.each( this.collection.models, function( model ) {
			model.attributes.loaded && model.attributes.player.stopVideo();
		});
	}

});