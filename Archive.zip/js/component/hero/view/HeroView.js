webcenter.HeroView = Backbone.View.extend({

	el: $( '.hero' ),

	activeHero: 0,
	lastHero: 0,
	interval: 0,
	transitionTimer: null,

	initialize: function() {
		_.bindAll( this, 'transitionTile', 'disableAutoplay' );

		this.heroCollection = new webcenter.Heros();

		this.heroMarkers = this.$( '.hero-markers' );
		this.interval = this.$el.data( 'interval' );
	},

	render: function() {
		var that = this;

		if( this.$el.find( '.hero-tile' ).length <= 0 ) { return this; }

		_.each( this.$el.find( '.hero-tile' ), function( heroTile ) {
			new webcenter.HeroTileView({
				el: heroTile,
				collection: that.heroCollection,
				heroMarkers: that.heroMarkers
			});
		});

		this.enableAutoplay();

		return this;
	},

	enableAutoplay: function() {
		this.lastHero = this.heroCollection.length - 1;
		this.startTransitionTimer();

		this.$el.on( 'click', '.hero-markers a', this.disableAutoplay );
	},

	disableAutoplay: function() {
		this.stopTransitionTimer();

		this.$el.off( 'click', '.hero-markers a' );
	},

	startTransitionTimer: function() {
		this.transitionTile(); // Start the first transition off immediately.
		this.transitionTimer = window.setInterval( this.transitionTile, this.interval );
	},

	stopTransitionTimer: function() {
		window.clearInterval( this.transitionTimer );
		this.transitionTimer = null;
	},

	transitionTile: function() {
		this.heroCollection.models[ this.activeHero ].set({ active: true });
		this.activeHero === this.lastHero ? this.activeHero = 0 : this.activeHero += 1;
	}

});