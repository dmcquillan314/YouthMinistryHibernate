webcenter.HeroTileView = Backbone.View.extend({

	viewIndex: null,

	initialize: function( options ) {
		this.heroMarkers = options.heroMarkers;

		this.listenToOnce( this.collection, 'add', this.addMarker );
		this.collection.add({ active: false });

		this.listenTo( this.collection.models[ this.viewIndex ], 'change:active', this.activateHero );
	},

	render: function() { return this; },

	addMarker: function( model ) {
		var view = new webcenter.HeroMarkerView({ model: model });

		this.viewIndex = this.collection.indexOf(model);

		this.viewIndex === 0 && this.$el.addClass( 'active' );
		this.$el.hasClass( 'active' ) && model.set({ active: true }, { silent: true });
		this.heroMarkers.append( view.render().el );
	},

	transitionFallback: function() {
		this.$el.siblings( '.hero-tile' ).animate( { transform: 'translateX(2000px)', display: 'none' }, { duration: 300, queue:false } );
		this.$el.animate({ transform: 'translateX(0px)', display: 'block' }, { duration: 300, queue:false });
	},

	activateHero: function() {
		this.$el.addClass( 'active' ).siblings().removeClass( 'active' );
		!Modernizr.csstransforms3d && this.transitionFallback();
	}

});