webcenter.HeroMarkerView = Backbone.View.extend({

	tagName:  'li',
	template: webcenter.heroMarkerTemplate,

	events: {
		'click a': 'activateMarker'
	},

	initialize: function() {
		this.listenTo( this.model, 'change', this.toggleActive );
	},

	render: function() {
		this.$el.html( this.template( this.model.toJSON() ) );

		return this;
	},

	activateMarker: function( event ) {
		event.preventDefault();
		!$( event.target ).hasClass( 'active' ) && this.model.set({ active: true });
	},

	toggleActive: function() {
		this.$el.find( 'a' ).toggleClass( 'active', this.model.get( 'active' ) );
	}

});