webcenter.Hero = Backbone.Model.extend({

	defaults: function() {
		return {
			active: false
		};
	}

});