webcenter.Heros = Backbone.Collection.extend({

	model: webcenter.Hero,

	initialize: function() {
		this.listenTo( this, 'change:active', this.collectionChange );
	},

	collectionChange: function( model ) {
		_.each( this.models, function( currentModel ) {
			if ( currentModel !== model && currentModel.get( 'active' ) ) {
				currentModel
					.set({ active: false }, { silent: true })
					.trigger( 'change', currentModel );
			}
		});
	}

});