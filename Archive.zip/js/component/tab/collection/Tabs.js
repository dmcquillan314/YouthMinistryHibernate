webcenter.Tabs = Backbone.Collection.extend({

	model: webcenter.Tab,

	initialize: function() {
		this.listenTo( this, 'change:active', this.collectionChange );
	},

	collectionChange: function( model ) {
		_.each( this.models, function( currentModel ) {
			if ( currentModel !== model && currentModel.get( 'active' ) ) {
				currentModel.set({ active: false }, { silent: true });
			}
		});
	}

});