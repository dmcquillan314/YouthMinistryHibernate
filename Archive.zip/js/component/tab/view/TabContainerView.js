webcenter.TabContainerView = Backbone.View.extend({

	el: $( '.tabs' ),

	hashList: [],
	contentList: null,

	initialize: function() {
		this.collection = new webcenter.Tabs();
		this.resizeTabs();
	},

	render: function() {
		var that = this;

		_.each( this.$( '.tab' ), function( tab ) {
			new webcenter.TabView({
				el: tab,
				collection: that.collection
			});
		});

		this.contentList = this.$el.next( '.tab-content' ).children();

		_.each( this.contentList, function( content, index ) {
			content.id = this.collection.models[ index ].get( 'contentId' );
		}, this );

		_.each( this.collection.models, function( model ) {
			this.hashList.push( '#' + model.get( 'contentId' )  );
		}, this);

		if ( !_.contains( this.hashList, window.location.hash ) ) {
			this.collection.models[ 0 ].set({ active: true });
			window.location.hash = this.hashList[ 0 ];
		}

		return this;
	},

	// We can't rely on flexbox or display:table, and a polyfill would be more
	// expensive so we resize manually.
	resizeTabs: function() {
		this.$el.children().css( 'width', this.$el.width() / this.el.children.length );
	}

});