webcenter.TabView = Backbone.View.extend({

	events: {
		'click': 'activateTab'
	},

	initialize: function() {
		_.bindAll( this, 'activateTab' );

		this.listenToOnce( this.collection, 'add', this.addTab );
		this.collection.add({
			active: false,
			contentId: this.$( 'a' ).text().replace(/ /g, '-')
		});

		this.listenTo( this.model, 'change:active', this.toggleActive );
	},

	render: function() { return this; },

	addTab: function( model ) {
		this.model = model;

		this.$( 'a' ).attr( 'href', '#' + model.get( 'contentId' ) );

		if ( window.location.hash === this.$( 'a' ).attr( 'href' ) ) {
			var that = this,
				hash = window.location.hash;

			window.location.hash = '';

			_.defer( function(){
				window.location.hash = hash;
				that.model.set({ active: true });
				that.$el.addClass( 'active' );
			});
		}
	},

	activateTab: function( event ) {
		event.preventDefault();

		var top = $( window ).scrollTop();
		window.location.href= event.target.href;
		$( window ).scrollTop( top );

		!$( event.target ).hasClass( 'active' ) && this.model.set({ active: true });
	},

	toggleActive: function() {
		this.$el.toggleClass( 'active', this.model.get( 'active' ) );
		this.$el.siblings().removeClass( 'active' );
	}

});