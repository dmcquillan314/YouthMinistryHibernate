webcenter.Tab = Backbone.Model.extend({

	defaults: function() {
		return {
			active: false,
			idName: null
		};
	}

});