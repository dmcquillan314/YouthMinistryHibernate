webcenter.Iframes = Backbone.Collection.extend({

	model: webcenter.Iframe,

	initialize: function() {}

});