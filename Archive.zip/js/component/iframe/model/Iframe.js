webcenter.Iframe = Backbone.Model.extend({

	defaults: function() {
		return {
		};
	}

});