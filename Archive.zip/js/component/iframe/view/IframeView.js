/* jshint undef: false, unused: false */

webcenter.IframeView = Backbone.View.extend({

	viewIndex: null,
	rpc: null,

	initialize: function( options ) {
		_.bindAll( this, 'addIframe', 'addListeners', 'resizeIframe' );

		this.listenToOnce( this.collection, 'add', this.addIframe );
		this.collection.add({});

		this.render();
	},

	render: function() {
		this.addListeners();
		return this;
	},

	addIframe: function( model ) {
		this.viewIndex = this.collection.indexOf(model);
	},

	addListeners: function() {
		var that = this;

		// bind event listeners with easyXDM
		this.rpc = new easyXDM.Rpc(
			{
				remote: this.$el.data("iframe-url"),
				container: this.el
			},
			{
				local: {
					resizeIframe: function( height, width ) {
						width = (typeof width === "undefined") ? "100%" : width;
						that.resizeIframe( height, width );
					}
				},
				remote: {}
			}
		);

	},

	resizeIframe: function( height, width ) {
		this.el.getElementsByTagName('iframe')[0].style.height = height + "px";
		this.el.getElementsByTagName('iframe')[0].style.width = /%/.test(width) ? width : width + "px";
	}

});