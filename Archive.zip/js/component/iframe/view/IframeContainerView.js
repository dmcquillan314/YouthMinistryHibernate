webcenter.IframeContainerView = Backbone.View.extend({

	el: $( '.msite' ),

	rpc: null,

	initialize: function() {
		_.bindAll( this, 'loadLib', 'loadLibs' );

		this.iframeCollection = new webcenter.Iframes();
	},

	loadLib: function( libUrl, callback ) {

		var script = document.createElement('script');

		script.async = true;
		script.src = libUrl;

		var entry  = document.getElementsByTagName('script')[0];
		entry.parentNode.insertBefore(script, entry);

		window.onload = script.onload = script.onreadystatechange = function() {
				var readyState = script.readyState;

				if (!readyState || /complete|loaded/.test(script.readyState)) {
					script.onload = null;
					script.onreadystatechange = null;
					window.onload = null;
					callback();
				}
		};
	},

	loadLibs: function() {
		var that = this,
			easyXDMURL = "/static/common/js/easyXDM.min.js";

		that.loadLib( easyXDMURL, function() { that.loadIframes(); });
	},

	loadIframes: function() {
		var that = this;

		_.each( this.$el, function( iframe ) {
			new webcenter.IframeView({
				el: iframe,
				collection: that.iframeCollection
			});
		});
	},

	render: function() {
		this.loadLibs();

		return this;
	}

});