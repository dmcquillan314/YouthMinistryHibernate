webcenter.AppView = Backbone.View.extend({

	el: $( 'body' ),

	components: {
		'accordion-component':'accordionComponent',
		'hero-component': 'heroComponent',
		'iframe-component': 'iframeComponent',
		'modal-component': 'modalComponent',
		'select-component': 'selectComponent',
		'tab-component': 'tabComponent',
		'video-component': 'videoComponent'
	},

	events: {},

	initialize: function() {
		this.loadComponents();
	},

	render: function() { return this; },

	loadComponents: function() {
		var components = [];

		_.each( this.$( '[data-require]' ), function( component ) {
			components.push( $( component ).data( 'require' ).split( ',' ) );
		}, this);

		_.each( _.uniq( _.flatten( components ) ), function( component ) {
			this[ this.components[ component ] ]();
		}, this);
	},

	heroComponent: function() {
		var heroView = new webcenter.HeroView();
		heroView.render();
	},

	accordionComponent: function() {
		var accordionView = new webcenter.AccordionView();
        accordionView.render();
	},

	modalComponent: function() {
		var modalContainerView = new webcenter.ModalContainerView();
		modalContainerView.render();
	},

	videoComponent: function() {
		var videoCollectionView = new webcenter.VideoCollectionView();
        videoCollectionView.render();
	},

	tabComponent: function() {
		var tabContainerView = new webcenter.TabContainerView();
		tabContainerView.render();
	},

	selectComponent: function() {
		var selectContainerView = new webcenter.SelectContainerView();
        selectContainerView.render();
	},

	iframeComponent: function() {
		var iframeContainerView = new webcenter.IframeContainerView();
        iframeContainerView.render();
	}

});