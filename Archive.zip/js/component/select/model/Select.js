webcenter.Select = Backbone.Model.extend({

	defaults: function() {
		return {
			active: false,
			optionsHash: {},
			placeholder: "please select&hellip;",
			selectedVal: null
		};
	}

});