webcenter.SelectContainerView = Backbone.View.extend({

	el: $( 'select' ),

	initialize: function() {
		_.bindAll( this );

		this.selectCollection = new webcenter.Selects();
	},

	render: function() {
		var that = this;

		_.each( this.$el, function( select ) {
			new webcenter.SelectView({
				el: select,
				collection: that.selectCollection
			});
		});

		return this;
	}

});