webcenter.SelectView = Backbone.View.extend({

	viewIndex: null,
	template: webcenter.SelectTemplate,
	firstKey: true,
	activeOption: null,
	optionLength: null,
	openedWithFocus: null,
	openedWithClick: null,
	maxHeight: 7,
	scrollPos: null,

	initialize: function( ) {
		_.bindAll( this, 'addSelect', 'toggleActive', 'activateSelect', 
						 'selectValue', 'deactivateSelect', 'renderUl', 
						 'clickHandler', 'handleKeyup', 'handleArrowNav',
						 'handleKeydown' );
		this.listenToOnce( this.collection, 'add', this.addSelect );
		this.collection.add({ active: false });

		this.listenTo( this.collection.models[ this.viewIndex ], 'change', this.toggleActive );
	},

	render: function() { return this;},

	renderUl: function( selectedVal, placeholder ) {
		this.collection.models[ this.viewIndex ].set({
			selectedVal: selectedVal,
			placeholder: placeholder ? placeholder : this.collection.models[ this.viewIndex ].defaults().placeholder
		});

		this.$el.wrap("<div class='select-container'>").after( this.template( this.collection.models[ this.viewIndex ].toJSON() ) );

		this.optionLength = this.$el.nextUntil('.select-ul-container').next().find('li').length;
		$(this.$el.nextUntil('.select-ul-container').next().find('li')[this.optionLength-1]).addClass('omega');
		this.$el.next().on( 'click', this.activateSelect );
		this.$el.next().children( "input[type='text']" ).on( 'focus', this.activateSelect );

	},

	addSelect: function( model ) {
		this.viewIndex = this.collection.indexOf(model);
		var optionsHash = model.get('optionsHash'),
			placeholder = this.$el.data( 'placeholder' ),
			selectedVal = this.$el.children('option[selected]').val();
		_.each( this.$el.children('option'), function( option ) {
			optionsHash[option.value] = option.innerHTML;
		});
		this.$el.hasClass( 'active' ) && model.set({ active: true, optionsHash: optionsHash, selectedVal: selectedVal }, { silent: true });

		this.renderUl( selectedVal, placeholder );
	},

	selectValue: function( e ) {
		var selectedItem = $(e.target);
		var selectedKey = selectedItem.data("key");
		this.collection.models[ this.viewIndex ].set({ active: false, selectedVal: selectedKey });
		this.$el.val(selectedKey);
		this.$el.next().children('input').val( this.collection.models[ this.viewIndex ].get('optionsHash')[selectedKey] );
		this.$el.nextUntil('.select-ul-container').next().find("li").unbind( 'click' );
	},

	activateSelect: function( event ) {
		if( event.type === 'focus') {
			this.openedWithFocus = true;
		} else {
			this.openedWithClick = true;
		}
		this.firstKey = true;
		event.stopPropagation();
		this.$el.next().children( "input[type='text']" ).unbind( 'focus' );

		if ( this.collection.models[ this.viewIndex ].get('active') ) {
			if(this.openedWithFocus) {
				this.openedWithFocus = !this.openedWithFocus;
			} else {
				this.deactivateSelect();
			}
			return false;
		}

		this.collection.models[ this.viewIndex ].set({ active: true });
		if( this.optionLength > this.maxHeight ) {
			this.$el.next().next().children('ul.select').css({ 
				'overflow': 'auto',
				'max-height': $(this.$el.next().next().find( 'li' )[0]).outerHeight() * this.maxHeight + 'px'
			});
		}

		$(document).unbind('click' ).one( 'click', this.clickHandler );
		$(document).on( 'keyup', this.handleKeyup );
		$(document).on( 'keydown', this.handleKeydown );
		return false;
	},

	clickHandler: function(e) {
		var $curTarget = $(e.target);

		if( $curTarget.hasClass( 'select-option' ) ) {
			this.selectValue( e );
		}

		this.deactivateSelect();
		$(document).unbind( 'click' );
	},

	handleKeydown: function(e) {
		var ar=new Array(33,34,35,36,37,38,39,40);
		var key = e.which;

		if($.inArray(key,ar) > -1) {
			e.preventDefault();
			return false;
		}
		return true;
	},

	handleKeyup: function(e) {
		
		switch(e.keyCode) {

			case 9: // tab
				if( this.firstKey && !this.openedWithClick ) { this.firstKey = !this.firstKey; return; }
				this.deactivateSelect();
				break;
			case 38: // up
				e.preventDefault();
				e.stopPropagation();
				if( this.activeOption === null ) {
					this.activeOption = this.optionLength - 1;
				}
				else {
					this.activeOption--;
					this.scrollPos = (this.activeOption - 1) * $(this.$el.next().next().find( 'li' )[0]).outerHeight();
				}
				this.handleArrowNav();
				break;
			case 40: // down
				e.preventDefault();
				e.stopPropagation();
				if( this.activeOption === null ) {this.activeOption = 0;}
				else {
					this.activeOption++;
					this.scrollPos = (this.activeOption - (this.maxHeight - 2)) * $(this.$el.next().next().find( 'li' )[0]).outerHeight();
				}
				this.handleArrowNav();
				break;
			case 13: // enter
			case 32: // spacebar
				this.$el.next().next().find('li.active').click();
				break;
		}
	},

	handleArrowNav: function() {
		this.activeOption = (this.activeOption < 0 ? this.optionLength : 0) + (this.activeOption % this.optionLength);
		if(this.activeOption === 0 ) {
			this.scrollPos = 0;
		} else if ( this.activeOption >= this.optionLength - 1 ) {
			this.scrollPos = $(this.$el.next().next().find( 'li' )[0]).outerHeight() * this.optionLength;
		}
		$(this.$el.nextUntil('.select').next().find('li')[ this.activeOption ]).addClass('active').siblings().removeClass('active');
		this.$el.nextUntil('.select').next().children('.select').scrollTop(this.scrollPos);
	},

	deactivateSelect: function() {
		this.collection.models[ this.viewIndex ].set({ active: false });
		this.$el.nextUntil('.select-ul-container').next().find('li').removeClass( 'active' );
		this.$el.next().children( "input[type='text']" ).on( 'focus', this.activateSelect );
		$(document).unbind('keyup');
		$(document).unbind('keydown');
		this.activeOption =  this.scrollPos = this.openedWithFocus = this.openedWithClick = null;
	},

	toggleActive: function() {
		this.$el.nextUntil('.select-ul-container').next().toggleClass( 'active', this.collection.models[ this.viewIndex ].get('active') );
		this.$el.nextUntil('.select-ul-container').toggleClass( 'active', this.collection.models[ this.viewIndex ].get('active') );
	}

});