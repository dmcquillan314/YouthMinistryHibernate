webcenter.ModalView = Backbone.View.extend({

	viewIndex: null,
	overlay: $( '#overlay-screen' ),
	close: $( '.close' ),

	broadcast: webcenter.broadcast,

	initialize: function( options ) {
		_.bindAll( this, 'openModal', 'closeModal', 'addListeners' );

		this.listenToOnce( this.collection, 'add', this.addModal );
		this.collection.add({ active: false, id: options.modalId });

		this.listenTo( this.collection.models[ this.viewIndex ], 'change:active', this.openModal );
	},

	render: function() { return this; },

	addModal: function( model ) {
		this.viewIndex = this.collection.indexOf(model);
	},

	addListeners: function() {
		var that = this;

		// bind event listeners
		this.overlay.one( 'click', this.closeModal );
		$( document ).one( 'keyup', function( event ) { event.which === 27 && that.closeModal(); } );
		this.close.one( 'click', this.closeModal );
	},

	openModal: function() {
		if ( this.collection.models[ this.viewIndex ].get( 'active' ) ) {
			// show whitewash
			this.overlay.addClass( 'active' );

			// close all modals
			this.closeAllButOverlay();

			$( '.modal' ).removeClass( 'active' );

			// open only the selected modal
			$( '#' + this.options.modalId ).addClass( 'active' );

			this.broadcast.trigger( 'video:openModal' );

			this.addListeners();
		}
	},

	closeAllButOverlay: function() {
		$( '.modal' ).removeClass( 'active' );
		this.broadcast.trigger( 'video:closeModal' );
	},

	closeModal: function() {
		this.overlay.removeClass( 'active' );
		$( '.modal' ).removeClass( 'active' );
		this.collection.models[ this.viewIndex ].set({ active: false });
		this.broadcast.trigger( 'video:closeModal' );
	}

});