webcenter.ModalContainerView = Backbone.View.extend({

	el: $( '.modal' ),

	initialize: function() {
		_.bindAll( this, 'enableModal', 'disableModal', 'activateModal' );

		this.modalCollection = new webcenter.Modals();
		this.modalLinks = $( '.modal-link' );
		this.enableModal();
	},

	render: function() {

		var that = this;

		_.each( this.$el, function( modal ) {
			new webcenter.ModalView({
				el: modal,
				modalId: modal.id,
				collection: that.modalCollection
			});
		});

		return this;
	},

	enableModal: function() {
		this.modalLinks.on( 'click', this.activateModal );
	},

	disableModal: function() {
		this.modalLinks.off( 'click' );
	},

	activateModal: function( event ) {
		var models = this.modalCollection.models,
			cur_target = $( event.currentTarget );

		_.each( models, function( model ) {
			if( cur_target.data( 'modal-id' ) === model.get( 'id' ) ) {
				model.set({ active: 'true' });
			}
		});
	}

});