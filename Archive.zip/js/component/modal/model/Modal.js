webcenter.Modal = Backbone.Model.extend({

	defaults: function() {
		return {
			active: false,
			id: null
		};
	}

});